I completed this project as part of Front-End Web Development with React course by The Hong Kong University of Science and Technology
Technologies-HTML,CSS,React Bootstrap 4 components,React Animations,React,Redux,React Router,Cross Fetch
